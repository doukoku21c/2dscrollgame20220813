using UnityEngine;
using System.Collections;

public class UIButtonManager : MonoBehaviour
{
    public void LeftClick()
    {

    }
    public void RightClick()
    { }

    public void JumpClick()
    {

    }
}
